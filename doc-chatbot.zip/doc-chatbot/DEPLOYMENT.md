# Doc Chatbot — Deployment Guide

## Overview

```
doc-chatbot/
├── worker/
│   ├── worker.js          ← Cloudflare Worker (backend)
│   ├── wrangler.jsonc     ← Worker config
│   └── upload-index.js   ← Script to push your doc index to KV
└── frontend/
    └── index.html         ← GitHub Pages (public chat UI)
```

---

## Step 1 — Export your document index

1. Open the **Doc Repo POC** artifact in Claude
2. Upload and index all your documents as usual
3. Click **Export** → saves `doc_repo_index.json` to your computer

---

## Step 2 — Create a Cloudflare KV namespace

1. Log in to [dash.cloudflare.com](https://dash.cloudflare.com)
2. Go to **Workers & Pages → KV**
3. Click **Create namespace** → name it `DOC_INDEX`
4. Copy the **Namespace ID** that appears

5. Open `worker/wrangler.jsonc` and replace:
   ```
   "REPLACE_WITH_YOUR_KV_NAMESPACE_ID"
   ```
   with your actual Namespace ID

---

## Step 3 — Deploy the Cloudflare Worker

```bash
# Install wrangler if you haven't already
npm install -g wrangler

# Authenticate
wrangler login

# From the worker/ directory:
cd worker
wrangler deploy
```

Note the Worker URL printed after deploy — it will look like:
`https://doc-chatbot.YOUR-SUBDOMAIN.workers.dev`

---

## Step 4 — Add Worker secrets

```bash
# Your Anthropic API key
wrangler secret put ANTHROPIC_API_KEY
# → paste your key when prompted

# Your Cloudflare Access AUD tag (get this in Step 6)
wrangler secret put CF_ACCESS_AUD
# → paste the AUD tag when prompted

# Your Cloudflare team domain (e.g. "mycompany" if your domain is mycompany.cloudflareaccess.com)
wrangler secret put CF_TEAM_DOMAIN
# → paste just the subdomain prefix (no .cloudflareaccess.com)
```

---

## Step 5 — Upload your document index to KV

```bash
# From the worker/ directory:
node upload-index.js /path/to/doc_repo_index.json
```

You'll see: `✓ Index uploaded to KV successfully`

To update the index later, just run this script again with a new export file.

---

## Step 6 — Set up Cloudflare Access

This protects your Worker so only allowed emails can use the chatbot.

1. In Cloudflare dashboard → **Zero Trust → Access → Applications**
2. Click **Add an application → Self-hosted**
3. Fill in:
   - **Application name**: Support Assistant
   - **Session duration**: 24 hours (or your preference)
   - **Application domain**: `doc-chatbot.YOUR-SUBDOMAIN.workers.dev`
4. Click **Next → Add a policy**
5. Policy name: `Allowed Users`
6. Under **Include**, choose **Emails** and add each allowed email address
7. Click **Save**
8. On the confirmation screen, copy the **AUD tag** — you'll need it for Step 4

---

## Step 7 — Deploy the frontend to GitHub Pages

1. Create a new GitHub repo (e.g. `support-chatbot`)
2. Open `frontend/index.html` and replace:
   ```javascript
   const WORKER_URL = "https://doc-chatbot.YOUR-SUBDOMAIN.workers.dev/chat";
   ```
   with your actual Worker URL from Step 3

3. Push the `frontend/` folder contents to the repo:
   ```bash
   cd frontend
   git init
   git remote add origin https://github.com/YOUR-USERNAME/support-chatbot.git
   git add .
   git commit -m "Initial deploy"
   git push -u origin main
   ```

4. In GitHub repo settings → **Pages**
   - Source: **Deploy from a branch**
   - Branch: `main` / `/ (root)`
   - Click **Save**

5. Your chatbot will be live at:
   `https://YOUR-USERNAME.github.io/support-chatbot`

---

## Step 8 — Lock down CORS (optional but recommended)

Once your GitHub Pages URL is confirmed, open `worker/worker.js` and update:

```javascript
"Access-Control-Allow-Origin": "*",
```

to:

```javascript
"Access-Control-Allow-Origin": "https://YOUR-USERNAME.github.io",
```

Then redeploy: `wrangler deploy`

---

## Updating the knowledge base

Whenever you have new or updated documents:

1. Open the POC tool in Claude
2. Import your existing `doc_repo_index.json` (to keep existing docs)
3. Add and index any new documents
4. Export the updated index
5. Run `node upload-index.js /path/to/new_index.json`

No redeployment of the Worker or frontend needed — KV updates instantly.

---

## Customising the chatbot UI

All UI is in `frontend/index.html`. Key things to change:

| Thing | Where |
|---|---|
| App name ("Support.") | `<div class="logo">` |
| Suggestion chips | `#chips` div |
| Accent colour | `--accent` CSS variable |
| Header subtitle | `.status-dot` div |

---

## Troubleshooting

**"Unauthorized" error in chat**
→ Cloudflare Access session may have expired. Refresh the page to re-authenticate.

**"No documents indexed yet" error**
→ KV upload may have failed. Re-run `upload-index.js` and check the Namespace ID in `wrangler.jsonc`.

**CORS error in browser console**
→ Make sure your GitHub Pages domain matches the `Access-Control-Allow-Origin` in `worker.js`.

**Worker not updating after changes**
→ Run `wrangler deploy` again from the `worker/` directory.
