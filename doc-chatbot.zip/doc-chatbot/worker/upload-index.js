#!/usr/bin/env node
/**
 * upload-index.js
 * Uploads your exported doc_repo_index.json to Cloudflare KV
 *
 * Usage:
 *   node upload-index.js ./doc_repo_index.json
 *
 * Prerequisites:
 *   npm install -g wrangler
 *   wrangler login
 */

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const indexFile = process.argv[2];
if (!indexFile) {
  console.error("Usage: node upload-index.js <path-to-doc_repo_index.json>");
  process.exit(1);
}

const absPath = path.resolve(indexFile);
if (!fs.existsSync(absPath)) {
  console.error(`File not found: ${absPath}`);
  process.exit(1);
}

const data = fs.readFileSync(absPath, "utf8");
let parsed;
try {
  parsed = JSON.parse(data);
} catch {
  console.error("Invalid JSON file");
  process.exit(1);
}

console.log(`Uploading index with ${parsed.length} document(s)...`);

// Write to a temp file (wrangler reads from file for large values)
const tmp = path.join(__dirname, "_tmp_index.json");
fs.writeFileSync(tmp, data);

try {
  execSync(`wrangler kv key put --binding=DOC_INDEX "index" --path="${tmp}"`, {
    stdio: "inherit",
    cwd: __dirname
  });
  console.log("✓ Index uploaded to KV successfully");
} catch (e) {
  console.error("Upload failed:", e.message);
} finally {
  fs.unlinkSync(tmp);
}
