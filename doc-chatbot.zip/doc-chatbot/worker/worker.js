/**
 * Doc Repo Chatbot — Cloudflare Worker
 * - Validates Cloudflare Access JWT on every request
 * - Loads document index from KV (DOC_INDEX)
 * - Proxies chat queries to Anthropic API
 * - Never exposes doc content or API key to the frontend
 */

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*", // Lock this down to your GitHub Pages domain in production
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Cf-Access-Jwt-Assertion",
};

export default {
  async fetch(request, env) {
    // Handle CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    // Only allow POST to /chat
    const url = new URL(request.url);
    if (url.pathname !== "/chat" || request.method !== "POST") {
      return new Response("Not found", { status: 404, headers: CORS_HEADERS });
    }

    // ── Cloudflare Access JWT validation ──────────────────────────────────
    // Cloudflare Access injects CF-Access-Jwt-Assertion on every request
    // that passes through an Access policy. We verify it here as a second
    // layer so direct Worker requests without Access are rejected.
    const jwt = request.headers.get("Cf-Access-Jwt-Assertion");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    // Validate JWT against your Cloudflare Access certs endpoint
    // AUD is your Access Application "Application Audience (AUD) Tag"
    const isValid = await verifyAccessJWT(jwt, env.CF_ACCESS_AUD, env.CF_TEAM_DOMAIN);
    if (!isValid) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    // ── Parse request ─────────────────────────────────────────────────────
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    const { message, history = [] } = body;
    if (!message || typeof message !== "string") {
      return new Response(JSON.stringify({ error: "Missing message" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    // ── Load doc index from KV ────────────────────────────────────────────
    let docs = [];
    try {
      const raw = await env.DOC_INDEX.get("index", { type: "json" });
      if (raw && Array.isArray(raw)) docs = raw;
    } catch (e) {
      console.error("KV read error:", e);
    }

    if (docs.length === 0) {
      return new Response(JSON.stringify({ error: "No documents indexed yet." }), {
        status: 503,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    // ── Build system prompt ───────────────────────────────────────────────
    const docContext = docs.map(d => `=== DOCUMENT: ${d.name} ===\n${d.extracted}`).join("\n\n");
    const systemPrompt = `You are a precise technical support assistant. Answer questions using ONLY the content from the internal knowledge base below.

Rules:
- Be precise and professional.
- Use numbered steps for troubleshooting guidance.
- If the answer is not in the knowledge base, say so clearly — do not guess.
- Do not reveal the names of source documents or that you are working from a document index.

KNOWLEDGE BASE:
${docContext}`;

    // ── Build message history ─────────────────────────────────────────────
    const safeHistory = Array.isArray(history)
      ? history.slice(-8).filter(h => h.role && h.content).map(h => ({
          role: h.role === "user" ? "user" : "assistant",
          content: String(h.content).slice(0, 4000)
        }))
      : [];

    const messages = [...safeHistory, { role: "user", content: message }];

    // ── Call Anthropic ────────────────────────────────────────────────────
    let answer;
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1024,
          system: systemPrompt,
          messages
        })
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      answer = data.content.filter(b => b.type === "text").map(b => b.text).join("");
    } catch (e) {
      console.error("Anthropic error:", e);
      return new Response(JSON.stringify({ error: "AI service error: " + e.message }), {
        status: 502,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }

    return new Response(JSON.stringify({ answer }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  }
};

// ── Cloudflare Access JWT verification ───────────────────────────────────────
async function verifyAccessJWT(token, aud, teamDomain) {
  try {
    const certsUrl = `https://${teamDomain}.cloudflareaccess.com/cdn-cgi/access/certs`;
    const certsRes = await fetch(certsUrl);
    const certs = await certsRes.json();

    // Decode JWT header to find key ID
    const [headerB64] = token.split(".");
    const header = JSON.parse(atob(headerB64.replace(/-/g, "+").replace(/_/g, "/")));
    const kid = header.kid;

    // Find matching public key
    const jwk = certs.keys?.find(k => k.kid === kid);
    if (!jwk) return false;

    // Import key and verify
    const key = await crypto.subtle.importKey(
      "jwk", jwk,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false, ["verify"]
    );

    const [, payloadB64, sigB64] = token.split(".");
    const signingInput = new TextEncoder().encode(`${headerB64}.${payloadB64}`);
    const sig = Uint8Array.from(atob(sigB64.replace(/-/g, "+").replace(/_/g, "/")), c => c.charCodeAt(0));

    const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, sig, signingInput);
    if (!valid) return false;

    // Check audience claim
    const payload = JSON.parse(atob(payloadB64.replace(/-/g, "+").replace(/_/g, "/")));
    if (payload.aud !== aud) return false;

    // Check expiry
    if (payload.exp < Math.floor(Date.now() / 1000)) return false;

    return true;
  } catch (e) {
    console.error("JWT verification error:", e);
    return false;
  }
}
